const log = Vue.createApp({
    data() {
        return {
            onlineStatus: false,
            /*email: '',*/
            /*password: '',*/
            activeUser: {
                name: '',
            },
            userID: '',
        }
    },
    methods: {
        nowOnline(){
            this.onlineStatus = true;
        },
        async logIn(id){
            let url = 'https://localhost:44385/api/User/' + id;
            axios.get(url).then(response => {this.activeUser = response.data})
            localStorage.setItem("userValue", JSON.stringify(this.activeUser.name));
            //this.nowOnline();
        },
        
    },
    mounted(){

    }
})