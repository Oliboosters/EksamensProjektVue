const createUserApp = Vue.createApp({
    data() {
        return {
            posts: {
                name: null,
                password: null,
                email: null,
                address: null,
                postalcode: null,
            },
            test: 'Hello',
        }
    },
    methods: {
        createUser(u){
            let url = 'https://localhost:44385/api/User';
            axios.post(url, this.posts).then((response) => { 
                console.log('User has been added to API: ' + response)       
            })
            u.preventDefault(); //prevents the Website from crashing when pressing Save button?
        },
    },   
})