app.component('navigation-bar', {
    props: {
        user: {
            type: Object
        },
        online: {
            type: Boolean
        }
    },
    template: /*html*/`
        <div>
            <!--Navbar-->
            <nav class="nav-wrapper">
                <div class="left-side">
                    <div class="nav-link-wrapper">
                        <a href="http://127.0.0.1:5500/HTML/index.html">Home</a>
                    </div>
                    <div v-if="onlineST">                     
                        <div>Welcome: {{user.name}}</div>
                    </div>
                    <div v-else>
                        <div class="nav-link-wrapper">
                            <a href="http://127.0.0.1:5500/HTML/Login.html">Log In</a>
                        </div>
                    </div>
                    <div class="nav-link-wrapper">
                            <a href="http://127.0.0.1:5500/HTML/Line-Up.html">Line Up</a>
                    </div>
                </div>

                <div class="right-side">
                    <div class="brand">
                        <div>Logo</div>
                    </div>
                </div>
            </nav>
        </div>
    `,
    data() {
        return {
            onlineST: false,
        }
    }, 
});