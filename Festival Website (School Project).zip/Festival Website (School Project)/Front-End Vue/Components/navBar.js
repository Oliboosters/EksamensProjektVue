app.component('navigation-bar', {
    template: /*html*/`
    <nav class="nav-wrapper">
        <div class="left-side">
            <div v-for="(link) in navLinks" class="nav-link-wrapper">
                <a :href="link.url">{{ link.name }}</a>
            </div>
        </div>

        <div class="right-side">
            <div class="brand">
                <div>Logo</div>
            </div>
        </div>
    </nav>
    `,
    data() {
        return {
            navLinks: [
                { name: 'Home', url: 'http://127.0.0.1:5500/HTML/index.html' },
                { name: 'About', url: '#'}
            ]
        }
    }, 
});