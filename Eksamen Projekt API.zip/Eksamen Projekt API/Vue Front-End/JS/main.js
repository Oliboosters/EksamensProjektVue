const app = Vue.createApp({
    data() {
        return {
            artists: [],
            artist: {},
            changedArtist: {
                id: null,
                name: null,
                info: null,
                imagePath: null,
            },
            show_artist: false,
            posts: {
                name: null,
                info: null,
                imagePath: null,
            },
            editID: '',
            activeUser: {},
            userID: '',
            onlineStatus: true,
        }
    },
    methods: {
        fetchAllArtists: function(){
            let url = 'https://localhost:44385/api/Artist';
            axios.get(url).then(response => { 
                this.artists = response.data
                console.log(this.artists)
            })
        },
        showArtist: function(id){
            let allArtists = this.artists;
            let clickedArtist = allArtists.filter(p => p.id == id);
            this.artist = clickedArtist;
            this.show_artist = true;
            console.log(clickedArtist);
        },
        beginEdit(id){
            this.editID = id;
        },
        stopEdit(){
            this.editID = '';
        },
        async editArtist(id){
            this.changedArtist.id = id;
            let url = 'https://localhost:44385/api/Artist/' + id;
            axios.put(url, this.changedArtist).then((response) => {
                console.log('Object has been updated: ' + response)
                this.fetchAllArtists();
            })
            this.editID = '';
        },
        showAllArtists(){
            this.show_artist = false;
        },
        createArtist(a){
            let url = 'https://localhost:44385/api/Artist';
            axios.post(url, this.posts).then((response) => { 
                console.log('Artist has been added to API: ' + response)       
            })
            a.preventDefault(); //prevents the Website from crashing when pressing Save button?
        },
        deleteArtist(id){
            let url = 'https://localhost:44385/api/Artist/' + id;
            axios.delete(url).then((response) => { 
                console.log('Artist has been deleted: ' + response)
                this.fetchAllArtists();
            })        
        },
        async logIn(id){
            let url = 'https://localhost:44385/api/User/' + id;
            axios.get(url).then(response => {this.activeUser = response.data})
            this.nowOnline();
        },
        nowOnline(){
            this.onlineStatus = true;
        },
    },  
    mounted(){
        this.fetchAllArtists()   
    }
})